/**
 * Created by Zanuck on 2016/6/2.
 */

$(function () {

    $('body').css('background-color','red');

});
