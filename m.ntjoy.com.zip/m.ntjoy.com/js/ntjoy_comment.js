/**
 * Created by Zanuck on 2016/5/20.
 */


//赞评论的点击事件
$('.j_favor_single').click(function () {
    var crt_count = parseInt($(this).html());
    $(this).html(crt_count + 1);
    $(this).append('<i class=\"fly\" style=\"display: inline-block\"></i>');
});

//我要评论点击事件
$('.cmntico').click(function () {
    $('.newarea').attr('placeholder', $(this).attr('data-sudaclick'));
    $('#pullLoaderContent').css('display', 'none');
    $('.cmnt_pop').css('display', 'block');
});
$('.foot_cmt_input').click(function () {
    $('#pullLoaderContent').css('display', 'none');
    $('.cmnt_pop').css('display', 'block');
});

//评论取消按钮点击事件
$('#j_cmnt_cancel').click(function () {
    $('#pullLoaderContent').css('display', 'block');
    $('.cmnt_pop').css('display', 'none');
});