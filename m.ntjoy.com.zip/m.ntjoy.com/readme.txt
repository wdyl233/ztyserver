江海明珠网wap端


纯美工
http://media.ntjoy.com/vod/vol1/2016-05-17/115253/14387.mp4


<div id="player"></div>
<script type="text/javascript" src="http://media.ntjoy.com/ckplayer/ckplayer.js" charset="utf-8"></script>
<script type="text/javascript">
  var flashvars={
    f:"http://media.ntjoy.com/vod/vol1/2016-05-17/115253/14387.mp4

",
    c:0,
    p:1,
    l:"http://media.ntjoy.com/flash-player/MockADS/ad15.swf",
    r:"http://www.ntjoy.com/tiaozhuan15.html",
    t:15,
    b:1,
    my_url:encodeURIComponent(window.location.href)
  };
  var video=["http://media.ntjoy.com/vod/vol1/2016-05-16/115236/14370.mp4->video/mp4"];
  CKobject.embed("http://media.ntjoy.com/ckplayer/ckplayer.swf","player","ckplayer_player","640","480",false,flashvars,video);
</script>